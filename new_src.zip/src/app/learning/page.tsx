'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase-client'
import CourseCard from '@/components/courses/CourseCard'
import { Sparkles, GraduationCap, Filter, ExternalLink } from 'lucide-react'
// Note: This page is client-side; auth gating should be done at route level if needed.


type Course = {
  id: string
  title: string
  description: string
  category: string
  thumbnail_url: string | null
  is_external: boolean
  is_certified: boolean
  enrollment_count: number
  resource_url: string | null
}

export default function LearningPage() {
  
  const [courses, setCourses] = useState<Course[]>([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState('all')
  const supabase = createClient()

  useEffect(() => {
    fetchCourses()
  }, [])

  const fetchCourses = async () => {
    try {
      const { data, error } = await supabase
        .from('courses')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setCourses(data || [])
    } catch (error) {
      console.error('Error fetching courses:', error)
    } finally {
      setLoading(false)
    }
  }

  const categories = ['all', 'Technical', 'Business', 'Soft Skills', 'Data Analytics']

  const filteredCourses = activeCategory === 'all'
    ? courses
    : courses.filter(c => c.category === activeCategory)

  return (
    <div className="min-h-screen bg-slate-50">
      {/* High-Contrast Hero Header */}
      <div className="bg-slate-900 pt-16 pb-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 mb-4">
            <Sparkles size={12} />
            <span className="text-[9px] font-black uppercase tracking-widest">Global Certifications</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black text-white tracking-tighter mb-4">
            <span className="text-yellow-500">MTN</span> Digital Skills Academy
          </h1>
          <p className="text-sm md:text-base text-slate-400 max-w-2xl mx-auto font-medium">
            Learn in-demand digital skills through MTN's Skills Academy — with Enactus opportunities and local support.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* MTN Skills Academy spotlight */}
        <section className="-mt-16 mb-10">
          <div className="rounded-[2.5rem] bg-white border border-slate-200 shadow-xl shadow-slate-900/10 overflow-hidden">
            <div className="p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="h-14 w-14 rounded-2xl bg-yellow-500/15 border border-yellow-500/20 flex items-center justify-center">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/9/93/MTN_Logo.svg"
                    alt="MTN"
                    className="h-8 w-8 object-contain"
                  />
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                    Primary Learning Platform
                  </p>
                  <h2 className="text-lg md:text-xl font-black text-slate-900 tracking-tight">
                    Continue your learning on MTN Digital Skills Academy
                  </h2>
                  <p className="text-sm text-slate-600 font-medium max-w-2xl mt-1">
                    Access MTN-curated courses, labs, and certificates — then come back here to apply for opportunities.
                  </p>
                </div>
              </div>

              <a
                href="https://skillsacademy.mtn.com/"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-900 px-6 py-4 font-black text-white hover:bg-slate-800 transition"
              >
                Open MTN Skills Academy <ExternalLink size={16} />
              </a>
            </div>
          </div>
        </section>

        {/* Category Filter - Compact & Professional */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-900 rounded-lg text-yellow-500">
              <Filter size={16} />
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
              Filter by Stream
            </span>
          </div>
          
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2 rounded-xl text-xs font-black transition-all tracking-tight ${
                  activeCategory === category
                    ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/20'
                    : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                }`}
              >
                {category === 'all' ? 'All Modules' : category}
              </button>
            ))}
          </div>
        </div>

        {/* Course Grid */}
        {loading ? (
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-80 animate-pulse rounded-[2rem] bg-slate-200 border border-slate-100" />
            ))}
          </div>
        ) : filteredCourses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center bg-white rounded-[3rem] border-2 border-dashed border-slate-200">
            <div className="bg-slate-50 w-20 h-20 rounded-3xl flex items-center justify-center mb-6 text-slate-300">
               <GraduationCap size={40} />
            </div>
            <h3 className="text-xl font-black text-slate-900 tracking-tight">No modules found</h3>
            <p className="text-slate-500 font-medium">We're currently updating this stream with new content.</p>
            <button 
              onClick={() => setActiveCategory('all')}
              className="mt-6 text-yellow-600 font-black text-sm hover:underline"
            >
              Back to all courses
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>
        )}

        {/* Professional Stats Footer */}
        {!loading && (
          <footer className="mt-20 border-t border-slate-200 pt-10 text-center">
            <div className="inline-flex items-center gap-6 px-8 py-3 bg-white rounded-full border border-slate-200 shadow-sm">
              <div className="flex flex-col">
                <span className="text-lg font-black text-slate-900 leading-none">{courses.length}</span>
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Modules</span>
              </div>
              <div className="w-px h-6 bg-slate-200"></div>
              <div className="flex flex-col">
                <span className="text-lg font-black text-slate-900 leading-none">
                  {courses.reduce((sum, c) => sum + c.enrollment_count, 0).toLocaleString()}
                </span>
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Learners</span>
              </div>
            </div>
          </footer>
        )}
      </div>
    </div>
  )
}