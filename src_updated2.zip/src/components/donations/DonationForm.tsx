'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase-client'
import { CreditCard, ShieldCheck, Send, Loader2, Info, Lock } from 'lucide-react'

export default function DonationForm() {
  const [paymentMethod, setPaymentMethod] = useState('momo')
  const [selectedAmount, setSelectedAmount] = useState<number | 'custom'>(100)
  const [amount, setAmount] = useState(100)
  const [loading, setLoading] = useState(false)

  const [donorName, setDonorName] = useState('')
  const [email, setEmail] = useState('')
  const [momoNumber, setMomoNumber] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const supabase = createClient()

  // Official Logo URLs
  const MTN_LOGO = "https://upload.wikimedia.org/wikipedia/commons/9/93/MTN_Logo.svg"
  const PAYPAL_LOGO = "https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg"

  const submitDonation = async () => {
    setError(null)
    setSuccess(null)

    // Basic validations
    const safeAmount = Number(amount)
    if (!Number.isFinite(safeAmount) || safeAmount <= 0) {
      setError('Please enter a valid amount.')
      return
    }
    if (!email.trim()) {
      setError('Email address is required.')
      return
    }
    if (paymentMethod === 'momo' && !momoNumber.trim()) {
      setError('Please enter your MTN MoMo number.')
      return
    }

    setLoading(true)
    try {
      // Record the donation intent. (Payment collection/integration can be wired later.)
      // We attempt a rich insert first, then fall back to minimal columns if your DB schema is simpler.
      const primaryPayload: any = {
        donor_name: donorName.trim() || null,
        email: email.trim(),
        amount: safeAmount,
        payment_method: paymentMethod,
        momo_number: paymentMethod === 'momo' ? momoNumber.trim() : null,
        status: 'pending',
      }

      let { error: insertError } = await supabase.from('donations').insert(primaryPayload)

      if (insertError) {
        // Fallback for lean schemas
        const fallbackPayload: any = {
          donor_name: donorName.trim() || null,
          amount: safeAmount,
        }
        const res2 = await supabase.from('donations').insert(fallbackPayload)
        if (res2.error) throw res2.error
      }

      setSuccess(
        paymentMethod === 'momo'
          ? 'Donation recorded. Please complete the MoMo transfer using your number and keep the reference for verification.'
          : 'Donation recorded. This payment method will be enabled soon.'
      )
      setDonorName('')
      setEmail('')
      setMomoNumber('')
      setSelectedAmount(100)
      setAmount(100)
      setPaymentMethod('momo')
    } catch (e: any) {
      setError(e?.message || 'Something went wrong while saving your donation. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-10">
      {/* 1. Amount Selection - High Contrast */}
      <div className="space-y-4">
        <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">
          Select Contribution (SZL)
        </label>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[100, 250, 500, 1000].map((amt) => (
            <button
              key={amt}
              type="button"
              onClick={() => {setSelectedAmount(amt); setAmount(amt)}}
              className={`py-4 rounded-2xl font-black text-sm transition-all border-2 ${
                selectedAmount === amt 
                  ? 'border-yellow-500 bg-yellow-500 text-slate-900 shadow-lg shadow-yellow-500/20' 
                  : 'border-slate-100 bg-slate-50 text-slate-600 hover:border-slate-200'
              }`}
            >
              E{amt}
            </button>
          ))}
          <button 
            type="button"
            onClick={() => setSelectedAmount('custom')}
            className={`py-4 rounded-2xl font-black text-xs border-2 transition-all ${
              selectedAmount === 'custom' 
                ? 'border-yellow-500 bg-yellow-500 text-slate-900' 
                : 'border-slate-100 bg-slate-50 text-slate-500'
            }`}
          >
            Custom
          </button>
        </div>

        {selectedAmount === 'custom' && (
          <div className="pt-2">
            <input
              type="number"
              min={1}
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full rounded-2xl border-2 border-slate-200 bg-white px-5 py-4 font-black text-slate-900 outline-none focus:border-yellow-500"
              placeholder="Enter amount (e.g. 150)"
            />
          </div>
        )}
      </div>

      {/* 2. Payment Methods with Branded Logos */}
      <div className="space-y-4">
        <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">
          Payment Method
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* MoMo Option (Primary) */}
          <button
            type="button"
            onClick={() => setPaymentMethod('momo')}
            className={`flex items-center justify-between gap-4 p-5 rounded-3xl border-2 transition-all ${
              paymentMethod === 'momo'
                ? 'border-yellow-400 bg-yellow-400 shadow-xl'
                : 'border-slate-100 bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <img src={MTN_LOGO} alt="MTN MoMo" className="h-8 w-8 object-contain" />
              <div className="text-left">
                <p className="text-xs font-black uppercase tracking-tight text-slate-900">MTN MoMo</p>
                <p className="text-[10px] font-bold text-slate-700">Recommended</p>
              </div>
            </div>
            <span className="text-[10px] font-black text-slate-900 bg-white/40 px-3 py-1 rounded-full">Primary</span>
          </button>

          {/* Card Option (Coming soon) */}
          <button
            type="button"
            onClick={() => setPaymentMethod('card')}
            className={`flex items-center justify-between gap-4 p-5 rounded-3xl border-2 transition-all ${
              paymentMethod === 'card'
                ? 'border-slate-900 bg-slate-900 text-white shadow-xl'
                : 'border-slate-100 bg-slate-50 text-slate-400'
            }`}
          >
            <div className="flex items-center gap-3">
              <CreditCard size={22} className={paymentMethod === 'card' ? 'text-yellow-500' : ''} />
              <div className="text-left">
                <p className="text-xs font-black uppercase tracking-tight">Card</p>
                <p className="text-[10px] font-bold opacity-80">Coming soon</p>
              </div>
            </div>
            <Lock size={16} className={paymentMethod === 'card' ? 'text-yellow-500' : ''} />
          </button>

          {/* PayPal Option (Coming soon) */}
          <button
            type="button"
            onClick={() => setPaymentMethod('paypal')}
            className={`flex items-center justify-between gap-4 p-5 rounded-3xl border-2 transition-all ${
              paymentMethod === 'paypal'
                ? 'border-[#003087] bg-[#003087] text-white shadow-xl'
                : 'border-slate-100 bg-slate-50 text-slate-400'
            }`}
          >
            <div className="flex items-center gap-3">
              <img src={PAYPAL_LOGO} alt="PayPal" className="h-7 w-7 object-contain brightness-0 invert" />
              <div className="text-left">
                <p className="text-xs font-black uppercase tracking-tight">PayPal</p>
                <p className="text-[10px] font-bold opacity-80">Coming soon</p>
              </div>
            </div>
            <Lock size={16} />
          </button>
        </div>
      </div>

      {/* 3. Branded Interaction Card (Dark Theme) */}
      <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden min-h-[220px] flex flex-col justify-center border border-slate-800">
        <div className="absolute top-0 right-0 p-8 opacity-10"><ShieldCheck size={100} /></div>
        
        {paymentMethod === 'momo' && (
          <div className="relative z-10 text-center animate-in zoom-in duration-300">
             <img src={MTN_LOGO} alt="MTN" className="h-12 w-12 mx-auto mb-4" />
             <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mb-4">Mobile Money Number</p>
             <input 
                type="tel"
                value={momoNumber}
                onChange={(e) => setMomoNumber(e.target.value)}
                className="w-full max-w-xs mx-auto block bg-slate-800 border border-slate-700 rounded-2xl px-6 py-4 text-center text-2xl font-black text-yellow-400 outline-none focus:border-yellow-500 transition-all" 
                placeholder="76•• ••••" 
             />
             <p className="mt-4 text-[11px] font-bold text-slate-400 max-w-md mx-auto">
               We’ll record your pledge here. Then you’ll complete the transfer via MoMo on your phone.
             </p>
          </div>
        )}

        {paymentMethod === 'card' && (
          <div className="relative z-10 space-y-4 animate-in slide-in-from-right-4">
             <input className="w-full bg-slate-800 border border-slate-700 rounded-xl px-6 py-4 text-lg font-bold tracking-widest outline-none focus:border-yellow-500 placeholder:text-slate-600" placeholder="CARD NUMBER" />
             <div className="grid grid-cols-2 gap-4">
               <input className="bg-slate-800 border border-slate-700 rounded-xl px-6 py-4 text-sm font-bold outline-none" placeholder="MM/YY" />
               <input className="bg-slate-800 border border-slate-700 rounded-xl px-6 py-4 text-sm font-bold outline-none" placeholder="CVC" />
             </div>
          </div>
        )}

        {paymentMethod === 'paypal' && (
          <div className="relative z-10 text-center animate-in zoom-in">
             <img src={PAYPAL_LOGO} alt="PayPal" className="h-10 w-10 mx-auto mb-4 brightness-0 invert" />
             <p className="text-slate-400 text-xs font-black uppercase tracking-widest">Redirecting to Secure Checkout</p>
          </div>
        )}
      </div>

      {/* 4. Donor Information & Final Action */}
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            value={donorName}
            onChange={(e) => setDonorName(e.target.value)}
            className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-black text-slate-900 text-sm outline-none focus:border-slate-900 placeholder:text-slate-400"
            placeholder="Full Name (Optional)"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-black text-slate-900 text-sm outline-none focus:border-slate-900 placeholder:text-slate-400"
            placeholder="Email Address *"
            required
          />
        </div>
        {(error || success) && (
          <div
            className={`rounded-2xl border p-4 flex items-start gap-3 ${
              error
                ? 'bg-rose-50 border-rose-200 text-rose-700'
                : 'bg-emerald-50 border-emerald-200 text-emerald-700'
            }`}
          >
            <Info size={18} className="mt-0.5" />
            <p className="text-sm font-bold leading-snug">{error || success}</p>
          </div>
        )}

        <button
          type="button"
          onClick={submitDonation}
          disabled={loading}
          className="w-full bg-yellow-500 hover:bg-yellow-400 disabled:opacity-60 disabled:cursor-not-allowed text-slate-900 py-6 rounded-[2rem] font-black text-xl shadow-xl shadow-yellow-500/20 flex items-center justify-center gap-3 transition-all active:scale-[0.98]"
        >
          {loading ? (
            <Loader2 className="animate-spin" />
          ) : (
            <>
              {paymentMethod === 'momo' ? 'Continue with MTN MoMo' : 'Save donation intent'} <Send size={20} />
            </>
          )}
        </button>
      </div>
    </div>
  )
}